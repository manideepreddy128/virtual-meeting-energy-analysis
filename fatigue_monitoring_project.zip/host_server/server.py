from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import time

from threading import Lock

app = FastAPI()

# =========================
# IN-MEMORY STORAGE
# =========================
students = {}   # student_id -> metrics
students_lock = Lock() # Locks access to students dict
SESSION_START = time.time()

# =========================
# DATA MODEL
# =========================
class StudentMetrics(BaseModel):
    student_id: str
    student_name: str
    ear: float # Keep raw EAR for debug
    eye_status: str     # "OPEN" / "CLOSED"
    fatigue: int        # PERCLOS %
    yawning_status: str # "YES" / "NO"
    head_status: str    # "NORMAL" / "ROTATED"
    status: str         # Final Status
    timestamp: float

# =========================
# DASHBOARD PAGE
# =========================
@app.get("/", response_class=HTMLResponse)
def dashboard():
    with open("dashboard/index.html", "r", encoding="utf-8") as f:
        return f.read()

# =========================
# RECEIVE STUDENT DATA
# =========================
@app.post("/update")
def update_student(data: StudentMetrics):
    with students_lock:
        students[data.student_id] = {
            "name": data.student_name,
            "name": data.student_name,
            "ear": data.ear,
            "eye_status": data.eye_status,
            "fatigue": data.fatigue,
            "yawning_status": data.yawning_status,
            "head_status": data.head_status,
            "status": data.status,
            "timestamp": data.timestamp
        }
    return {"message": "updated"}

# =========================
# SEND DATA TO DASHBOARD
# =========================
@app.get("/students")
def get_students():
    now = time.time()
    inactive = []

    with students_lock:
        # AUTO REMOVE DISCONNECTED STUDENTS
        for sid, s in list(students.items()): # Create copy for safe iteration
            if now - s["timestamp"] > 10:
                inactive.append(sid)

        for sid in inactive:
            del students[sid]
            
        return JSONResponse(content=students)
