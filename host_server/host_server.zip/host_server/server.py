from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import time

app = FastAPI()

# =========================
# IN-MEMORY STORAGE
# =========================
students = {}   # student_id -> metrics
SESSION_START = time.time()

# =========================
# DATA MODEL
# =========================
class StudentMetrics(BaseModel):
    student_id: str
    ear: float
    blink_rate: float
    fatigue: int
    status: str
    timestamp: float

# =========================
# DASHBOARD PAGE
# =========================
@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
<!DOCTYPE html>
<html>
<head>
    <title>Student Engagement & Fatigue Dashboard</title>
    <style>
        body {
            background-color: #0f172a;
            color: white;
            font-family: Arial, sans-serif;
            padding: 30px;
        }
        h1 {
            margin-bottom: 5px;
        }
        .note {
            color: #94a3b8;
            margin-bottom: 20px;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }
        .card {
            background: #1e293b;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }
        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #334155;
            text-align: center;
        }
        th {
            background: #1e293b;
        }
    </style>
</head>
<body>

<h1>Student Engagement & Fatigue Dashboard</h1>
<div class="note">🔒 Privacy: Only numerical metrics processed. No video stored.</div>

<div class="cards">
    <div class="card"><h2 id="total">0</h2>Total</div>
    <div class="card"><h2 id="active">0</h2>Active</div>
    <div class="card"><h2 id="passive">0</h2>Passive</div>
    <div class="card"><h2 id="distracted">0</h2>Distracted</div>
</div>

<table>
    <thead>
        <tr>
            <th>Student ID</th>
            <th>EAR</th>
            <th>Blink Rate</th>
            <th>Fatigue</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody id="studentTable"></tbody>
</table>

<script>
async function loadData() {
    const res = await fetch("/students");
    const data = await res.json();

    let total = 0, active = 0, passive = 0, distracted = 0;
    const table = document.getElementById("studentTable");
    table.innerHTML = "";

    for (const id in data) {
        total++;
        const s = data[id];
        if (s.status === "ACTIVE") active++;
        else if (s.status === "PASSIVE") passive++;
        else distracted++;

        table.innerHTML += `
        <tr>
            <td>${id}</td>
            <td>${s.ear.toFixed(2)}</td>
            <td>${s.blink_rate.toFixed(1)}</td>
            <td>${s.fatigue}</td>
            <td>${s.status}</td>
        </tr>`;
    }

    document.getElementById("total").innerText = total;
    document.getElementById("active").innerText = active;
    document.getElementById("passive").innerText = passive;
    document.getElementById("distracted").innerText = distracted;
}

setInterval(loadData, 2000);
loadData();
</script>

</body>
</html>
"""

# =========================
# RECEIVE STUDENT DATA
# =========================
@app.post("/update")
def update_student(data: StudentMetrics):
    students[data.student_id] = {
        "ear": data.ear,
        "blink_rate": data.blink_rate,
        "fatigue": data.fatigue,
        "status": data.status,
        "timestamp": data.timestamp
    }
    return {"message": "updated"}

# =========================
# SEND DATA TO DASHBOARD
# =========================
@app.get("/students")
def get_students():
    now = time.time()
    inactive = []

    # AUTO REMOVE DISCONNECTED STUDENTS
    for sid, s in students.items():
        if now - s["timestamp"] > 10:
            inactive.append(sid)

    for sid in inactive:
        del students[sid]

    return JSONResponse(content=students)
